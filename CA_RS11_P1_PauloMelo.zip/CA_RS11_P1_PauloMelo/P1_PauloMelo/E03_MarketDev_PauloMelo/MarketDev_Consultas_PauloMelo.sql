USE MarketDev_RS_P1;
GO

/*
-- 3.21
SELECT
	ISNULL(p.Color, '<...>') AS Color,
	c.CategoryName AS Category,
	s.SubcategoryName AS Subcategory,
	p.ProductName AS Product,
	ISNULL(p.Size, '') AS 'Size unit'
FROM Marketing.Product AS p
JOIN Marketing.Subcategory AS s
ON s.SubcategoryID = p.SubcategoryID
JOIN Marketing.Category AS c
ON c.CategoryID = s.CategoryID
ORDER BY Color, Category, Subcategory;
GO
*/

/*
-- 3.22
SELECT
	DATEDIFF(YEAR, p.SellStartDate, p.SellEndDate) AS 'Sell years',
	DATEDIFF(MONTH, p.SellStartDate, p.SellEndDate) AS 'Sell months',
	DATEDIFF(DAY, p.SellStartDate, p.SellEndDate) AS 'Sell days',
	FORMAT(p.SellStartDate, 'dd/MM/yyyy') AS 'Sell start',
	FORMAT(p.SellEndDate, 'dd/MM/yyyy')  AS 'Sell end',
	p.ProductName AS Product,
	FORMAT(p.ListPrice, 'N2', 'pt-PT') + '�' AS 'List price'
FROM Marketing.Product AS p
WHERE 
	p.SellStartDate BETWEEN '01/07/2005' AND '01/07/2006'
ORDER BY 'Sell years' DESC;
GO
*/

/*
-- 3.24
SELECT
	s.FirstName + ' ' + UPPER(s.LastName) AS 'Salesperson',
	LOWER(s.FirstName) + '.' + LOWER(s.LastName) + '_' + LOWER(REPLACE(st.Country, ' ', '')) + '.' + LOWER(st.Region) + '@restart.com',
	st.Country,
	st.Region
FROM Marketing.Salesperson AS s
JOIN Marketing.SalesTerritory AS st
ON st.SalesTerritoryID = s.SalesTerritoryID
WHERE st.Region = 'Europe'
ORDER BY s.FirstName;
GO
*/

/*
-- 3.25
SELECT
	st.Region,
	st.Country,
	COUNT(s.SalespersonID) AS 'Total salesperson'
FROM Marketing.Salesperson as s
JOIN Marketing.SalesTerritory AS st
ON s.SalesTerritoryID = st.SalesTerritoryID
GROUP BY st.Region, st.Country
ORDER BY st.Region, st.Country;
GO
*/

/*
-- 3.26
SELECT
    p.FirstName + COALESCE(' ' + p.MiddleName, '') + ' ' + p.LastName AS Prospecter,
	COALESCE(p.CellPhoneNumber, p.HomePhoneNumber, p.WorkPhoneNumber) AS 'Contact number',
	COALESCE(p.EmailAddress, '<to be updated>') AS 'E-mail'
FROM Marketing.Prospect AS p
WHERE p.EmailAddress IS NULL
ORDER BY p.FirstName;
GO
*/

/*
-- 3.27
SELECT TOP 1
    pm.ProductModel AS 'Product model',
    pm.Description AS 'Product description'
FROM Marketing.ProductModel AS pm
LEFT JOIN Marketing.Product AS p
    ON p.ProductModelID = pm.ProductModelID
WHERE p.ProductModelID IS NULL
ORDER BY pm.ProductModel DESC;
GO
*/
