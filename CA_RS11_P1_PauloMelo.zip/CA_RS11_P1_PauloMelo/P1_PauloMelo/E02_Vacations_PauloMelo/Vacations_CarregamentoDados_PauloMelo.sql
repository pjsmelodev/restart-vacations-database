USE Vacations_PauloMelo;
GO

-- 2.11

-- Inser��o de departamento
INSERT INTO dbo.Department (DepartmentName)
VALUES ('Tecnologias de Informacao');
GO

-- Inser��o de manager
INSERT INTO DBO.Manager (ManagerCode, FirstName, MiddleName, LastName)
VALUES ('PT-PRT-HR-000012', 'Carolina', 'Franco de', 'Lima');
GO

-- Inser��o de funcion�rio
INSERT INTO dbo.Employee (EmployeeCode, FirstName, MiddleName, LastName, DepartmentID)
VALUES 
	('PT-PRT-TI-000120', 'Maria', 'Antonia de Castro e', 'Sa',
	(SELECT DepartmentID FROM dbo.Department WHERE DepartmentName = 'Tecnologias de Informacao'));
GO

-- Inser��o de pedido de f�rias
INSERT INTO dbo.VacationRequest (RequestDate, ApprovalDate, ManagerID, EmployeeID)
VALUES 
	('2019-02-25', '2019-03-04',
	(SELECT ManagerID FROM dbo.Manager WHERE ManagerCode = 'PT-PRT-HR-000012'),
	(SELECT EmployeeID FROM dbo.Employee WHERE EmployeeCode = 'PT-PRT-TI-000120'));
GO

-- Inser��o dos per�odos de f�rias
INSERT INTO dbo.VacationPeriod (RequestID, StartDate, EndDate, Approved)
VALUES 
	((SELECT RequestID FROM dbo.VacationRequest WHERE RequestDate = '2019-02-25' AND ApprovalDate = '2019-03-04'),
	'2019-03-04', '2019-03-08', 'Yes'),
	((SELECT RequestID FROM VacationRequest WHERE RequestDate = '2019-02-25' AND ApprovalDate = '2019-03-04'),
	'2019-07-29', '2019-08-16', 'Yes'),
	((SELECT RequestID FROM VacationRequest WHERE RequestDate = '2019-02-25' AND ApprovalDate = '2019-03-04'),
	'2019-12-23', '2020-01-03', 'No');
GO