-- 2.13

USE [master]
GO
/****** Object:  Database [Vacations_PauloMelo]    Script Date: 2/18/2025 10:02:10 PM ******/
CREATE DATABASE [Vacations_PauloMelo]
 CONTAINMENT = NONE
 ON  PRIMARY 
( NAME = N'Vacations_PauloMelo', FILENAME = N'C:\Restart11\Data\Vacations_PauloMelo.mdf' , SIZE = 8192KB , MAXSIZE = UNLIMITED, FILEGROWTH = 65536KB )
 LOG ON 
( NAME = N'Vacations_PauloMelo_log', FILENAME = N'C:\Restart11\Data\Vacations_PauloMelo_log.ldf' , SIZE = 8192KB , MAXSIZE = 2048GB , FILEGROWTH = 65536KB )
 WITH CATALOG_COLLATION = DATABASE_DEFAULT, LEDGER = OFF
GO
ALTER DATABASE [Vacations_PauloMelo] SET COMPATIBILITY_LEVEL = 160
GO
IF (1 = FULLTEXTSERVICEPROPERTY('IsFullTextInstalled'))
begin
EXEC [Vacations_PauloMelo].[dbo].[sp_fulltext_database] @action = 'enable'
end
GO
ALTER DATABASE [Vacations_PauloMelo] SET ANSI_NULL_DEFAULT OFF 
GO
ALTER DATABASE [Vacations_PauloMelo] SET ANSI_NULLS OFF 
GO
ALTER DATABASE [Vacations_PauloMelo] SET ANSI_PADDING OFF 
GO
ALTER DATABASE [Vacations_PauloMelo] SET ANSI_WARNINGS OFF 
GO
ALTER DATABASE [Vacations_PauloMelo] SET ARITHABORT OFF 
GO
ALTER DATABASE [Vacations_PauloMelo] SET AUTO_CLOSE OFF 
GO
ALTER DATABASE [Vacations_PauloMelo] SET AUTO_SHRINK OFF 
GO
ALTER DATABASE [Vacations_PauloMelo] SET AUTO_UPDATE_STATISTICS ON 
GO
ALTER DATABASE [Vacations_PauloMelo] SET CURSOR_CLOSE_ON_COMMIT OFF 
GO
ALTER DATABASE [Vacations_PauloMelo] SET CURSOR_DEFAULT  GLOBAL 
GO
ALTER DATABASE [Vacations_PauloMelo] SET CONCAT_NULL_YIELDS_NULL OFF 
GO
ALTER DATABASE [Vacations_PauloMelo] SET NUMERIC_ROUNDABORT OFF 
GO
ALTER DATABASE [Vacations_PauloMelo] SET QUOTED_IDENTIFIER OFF 
GO
ALTER DATABASE [Vacations_PauloMelo] SET RECURSIVE_TRIGGERS OFF 
GO
ALTER DATABASE [Vacations_PauloMelo] SET  DISABLE_BROKER 
GO
ALTER DATABASE [Vacations_PauloMelo] SET AUTO_UPDATE_STATISTICS_ASYNC OFF 
GO
ALTER DATABASE [Vacations_PauloMelo] SET DATE_CORRELATION_OPTIMIZATION OFF 
GO
ALTER DATABASE [Vacations_PauloMelo] SET TRUSTWORTHY OFF 
GO
ALTER DATABASE [Vacations_PauloMelo] SET ALLOW_SNAPSHOT_ISOLATION OFF 
GO
ALTER DATABASE [Vacations_PauloMelo] SET PARAMETERIZATION SIMPLE 
GO
ALTER DATABASE [Vacations_PauloMelo] SET READ_COMMITTED_SNAPSHOT OFF 
GO
ALTER DATABASE [Vacations_PauloMelo] SET HONOR_BROKER_PRIORITY OFF 
GO
ALTER DATABASE [Vacations_PauloMelo] SET RECOVERY SIMPLE 
GO
ALTER DATABASE [Vacations_PauloMelo] SET  MULTI_USER 
GO
ALTER DATABASE [Vacations_PauloMelo] SET PAGE_VERIFY CHECKSUM  
GO
ALTER DATABASE [Vacations_PauloMelo] SET DB_CHAINING OFF 
GO
ALTER DATABASE [Vacations_PauloMelo] SET FILESTREAM( NON_TRANSACTED_ACCESS = OFF ) 
GO
ALTER DATABASE [Vacations_PauloMelo] SET TARGET_RECOVERY_TIME = 60 SECONDS 
GO
ALTER DATABASE [Vacations_PauloMelo] SET DELAYED_DURABILITY = DISABLED 
GO
ALTER DATABASE [Vacations_PauloMelo] SET ACCELERATED_DATABASE_RECOVERY = OFF  
GO
ALTER DATABASE [Vacations_PauloMelo] SET QUERY_STORE = ON
GO
ALTER DATABASE [Vacations_PauloMelo] SET QUERY_STORE (OPERATION_MODE = READ_WRITE, CLEANUP_POLICY = (STALE_QUERY_THRESHOLD_DAYS = 30), DATA_FLUSH_INTERVAL_SECONDS = 900, INTERVAL_LENGTH_MINUTES = 60, MAX_STORAGE_SIZE_MB = 1000, QUERY_CAPTURE_MODE = AUTO, SIZE_BASED_CLEANUP_MODE = AUTO, MAX_PLANS_PER_QUERY = 200, WAIT_STATS_CAPTURE_MODE = ON)
GO
USE [Vacations_PauloMelo]
GO
/****** Object:  Table [dbo].[Department]    Script Date: 2/18/2025 10:02:10 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Department](
	[DepartmentID] [int] IDENTITY(1,1) NOT NULL,
	[DepartmentName] [varchar](255) NOT NULL,
 CONSTRAINT [PK_Department] PRIMARY KEY CLUSTERED 
(
	[DepartmentID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Employee]    Script Date: 2/18/2025 10:02:10 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Employee](
	[EmployeeID] [int] IDENTITY(1,1) NOT NULL,
	[EmployeeCode] [varchar](50) NOT NULL,
	[FirstName] [varchar](100) NOT NULL,
	[MiddleName] [varchar](100) NULL,
	[LastName] [varchar](100) NOT NULL,
	[DepartmentID] [int] NOT NULL,
 CONSTRAINT [PK_Employee] PRIMARY KEY CLUSTERED 
(
	[EmployeeID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Manager]    Script Date: 2/18/2025 10:02:10 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Manager](
	[ManagerID] [int] IDENTITY(1,1) NOT NULL,
	[ManagerCode] [varchar](50) NOT NULL,
	[FirstName] [varchar](100) NOT NULL,
	[MiddleName] [varchar](100) NULL,
	[LastName] [varchar](100) NOT NULL,
 CONSTRAINT [PK_Manager] PRIMARY KEY CLUSTERED 
(
	[ManagerID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[VacationPeriod]    Script Date: 2/18/2025 10:02:10 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[VacationPeriod](
	[VacationPeriodID] [int] IDENTITY(1,1) NOT NULL,
	[RequestID] [int] NOT NULL,
	[StartDate] [date] NOT NULL,
	[EndDate] [date] NOT NULL,
	[Approved] [varchar](3) NULL,
 CONSTRAINT [PK_VacationPeriod] PRIMARY KEY CLUSTERED 
(
	[VacationPeriodID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[VacationRequest]    Script Date: 2/18/2025 10:02:10 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[VacationRequest](
	[RequestID] [int] IDENTITY(1,1) NOT NULL,
	[RequestDate] [date] NOT NULL,
	[ApprovalDate] [date] NULL,
	[ManagerID] [int] NOT NULL,
	[EmployeeID] [int] NOT NULL,
 CONSTRAINT [PK_VacationRequest] PRIMARY KEY CLUSTERED 
(
	[RequestID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
SET IDENTITY_INSERT [dbo].[Department] ON 
GO
INSERT [dbo].[Department] ([DepartmentID], [DepartmentName]) VALUES (1, N'Tecnologias de Informacao')
GO
SET IDENTITY_INSERT [dbo].[Department] OFF
GO
SET IDENTITY_INSERT [dbo].[Employee] ON 
GO
INSERT [dbo].[Employee] ([EmployeeID], [EmployeeCode], [FirstName], [MiddleName], [LastName], [DepartmentID]) VALUES (1, N'PT-PRT-TI-000120', N'Maria', N'Antonia de Castro e', N'Sa', 1)
GO
SET IDENTITY_INSERT [dbo].[Employee] OFF
GO
SET IDENTITY_INSERT [dbo].[Manager] ON 
GO
INSERT [dbo].[Manager] ([ManagerID], [ManagerCode], [FirstName], [MiddleName], [LastName]) VALUES (1, N'PT-PRT-HR-000012', N'Carolina', N'Franco de', N'Lima')
GO
SET IDENTITY_INSERT [dbo].[Manager] OFF
GO
SET IDENTITY_INSERT [dbo].[VacationPeriod] ON 
GO
INSERT [dbo].[VacationPeriod] ([VacationPeriodID], [RequestID], [StartDate], [EndDate], [Approved]) VALUES (1, 1, CAST(N'2019-03-04' AS Date), CAST(N'2019-03-08' AS Date), N'Yes')
GO
INSERT [dbo].[VacationPeriod] ([VacationPeriodID], [RequestID], [StartDate], [EndDate], [Approved]) VALUES (2, 1, CAST(N'2019-07-29' AS Date), CAST(N'2019-08-16' AS Date), N'Yes')
GO
INSERT [dbo].[VacationPeriod] ([VacationPeriodID], [RequestID], [StartDate], [EndDate], [Approved]) VALUES (3, 1, CAST(N'2019-12-23' AS Date), CAST(N'2020-01-03' AS Date), N'No')
GO
SET IDENTITY_INSERT [dbo].[VacationPeriod] OFF
GO
SET IDENTITY_INSERT [dbo].[VacationRequest] ON 
GO
INSERT [dbo].[VacationRequest] ([RequestID], [RequestDate], [ApprovalDate], [ManagerID], [EmployeeID]) VALUES (1, CAST(N'2019-02-25' AS Date), CAST(N'2019-03-04' AS Date), 1, 1)
GO
SET IDENTITY_INSERT [dbo].[VacationRequest] OFF
GO
ALTER TABLE [dbo].[Employee]  WITH CHECK ADD  CONSTRAINT [FK_Employee_Department] FOREIGN KEY([DepartmentID])
REFERENCES [dbo].[Department] ([DepartmentID])
GO
ALTER TABLE [dbo].[Employee] CHECK CONSTRAINT [FK_Employee_Department]
GO
ALTER TABLE [dbo].[VacationPeriod]  WITH CHECK ADD  CONSTRAINT [FK_VacationPeriod_VacationRequest] FOREIGN KEY([RequestID])
REFERENCES [dbo].[VacationRequest] ([RequestID])
GO
ALTER TABLE [dbo].[VacationPeriod] CHECK CONSTRAINT [FK_VacationPeriod_VacationRequest]
GO
ALTER TABLE [dbo].[VacationRequest]  WITH CHECK ADD  CONSTRAINT [FK_VacationRequest_Employee] FOREIGN KEY([EmployeeID])
REFERENCES [dbo].[Employee] ([EmployeeID])
GO
ALTER TABLE [dbo].[VacationRequest] CHECK CONSTRAINT [FK_VacationRequest_Employee]
GO
ALTER TABLE [dbo].[VacationRequest]  WITH CHECK ADD  CONSTRAINT [FK_VacationRequest_Manager] FOREIGN KEY([ManagerID])
REFERENCES [dbo].[Manager] ([ManagerID])
GO
ALTER TABLE [dbo].[VacationRequest] CHECK CONSTRAINT [FK_VacationRequest_Manager]
GO
USE [master]
GO
ALTER DATABASE [Vacations_PauloMelo] SET  READ_WRITE 
GO
