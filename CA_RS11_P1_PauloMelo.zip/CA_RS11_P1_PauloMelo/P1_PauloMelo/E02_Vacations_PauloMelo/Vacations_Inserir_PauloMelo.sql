-- 2.14

USE Vacations_PauloMelo;
GO

INSERT INTO dbo.Department (DepartmentName)
VALUES
	('Comercial'),
	('Administracao');
GO