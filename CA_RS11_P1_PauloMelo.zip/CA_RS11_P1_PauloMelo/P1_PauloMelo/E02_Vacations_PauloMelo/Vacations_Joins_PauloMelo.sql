USE Vacations_PauloMelo;
GO

-- 2.12

SELECT
	vr.RequestID AS RequestFormNumber,
	vr.RequestDate,
	vr.ApprovalDate,
	m.ManagerCode,
	(m.FirstName + ' ' + m.MiddleName + ' ' + m.LastName) AS ManagerName,
	e.EmployeeCode,
	(e.FirstName + ' ' + e.MiddleName + ' ' + e.LastName) AS EmployeeName,
	d.DepartmentName AS Department,
	vp.VacationPeriodID AS #,
	vp.StartDate,
	vp.EndDate,
	DATEDIFF(DAY, vp.StartDate, vp.EndDate) AS TotalDays,
	vp.Approved
FROM dbo.VacationRequest AS vr
JOIN dbo.Manager AS m
ON m.ManagerID = vr.ManagerID
JOIN dbo.Employee AS e
ON vr.EmployeeID = e.EmployeeID
JOIN dbo.Department AS d
ON d.DepartmentID = e.DepartmentID
JOIN dbo.VacationPeriod AS vp
ON vp.RequestID = vr.RequestID;
GO