USE Vacations_PauloMelo;
GO

/*
-- 2.15

-- Atualiza��o do nome da Manager
UPDATE dbo.Manager
SET
	MiddleName = 'Lima de',
	LastName = 'Franca'
WHERE ManagerID = 1;
GO

-- Atualiza��o do c�digo do Employee
UPDATE dbo.Employee
SET EmployeeCode = 'PT-PRT-SI-000120'
WHERE EmployeeID = 1
GO

-- Atualiza��o do Departamento
UPDATE dbo.Department
SET DepartmentName = 'Sistemas de Informacao'
WHERE DepartmentName = 'Tecnologias de Informacao';
GO

-- Atualizar o vacation period n� 3
UPDATE dbo.VacationPeriod
SET
	EndDate = '2019-12-31',
	Approved = 'Yes'
WHERE VacationPeriodID = 3;
GO
*/

-- 2.16

-- Pedido de f�rias n� 2

-- Inser��o de Departamento
INSERT INTO dbo.Department (DepartmentName)
VALUES ('Financeiro');
GO

-- Inser��o de Manager
INSERT INTO dbo.Manager (ManagerCode, FirstName, MiddleName, LastName)
VALUES ('PT-PRT-HR-000003', 'Mario', '', 'Ramos');
GO

-- Inser��o dos Funcion�rios
INSERT INTO dbo.Employee (EmployeeCode, FirstName, MiddleName, LastName, DepartmentID)
VALUES
	('PT-LIS-FI-00083', 'Rui', 'Pina de', 'Oliveira',
	(SELECT DepartmentID FROM dbo.Department WHERE DepartmentName = 'Financeiro')),
	('PT-BRG-AD-000100', 'Maria', 'Teresa Vale dos', 'Santos',
	(SELECT DepartmentID FROM dbo.Department WHERE DepartmentName = 'Administracao'));
GO

-- Inser��o do pedido n� 2
INSERT INTO dbo.VacationRequest (RequestDate, ApprovalDate, ManagerID, EmployeeID)
VALUES
	('2019-02-26', '2019-03-06',
	(SELECT ManagerID FROM dbo.Manager WHERE ManagerCode = 'PT-PRT-HR-000003'),
	(SELECT EmployeeID FROM dbo.Employee WHERE EmployeeCode = 'PT-LIS-FI-00083'));
GO

-- Inser��o dos per�odos de f�rias do pedido n� 2
INSERT INTO dbo.VacationPeriod (RequestID, StartDate, EndDate, Approved)
VALUES
    (
        (SELECT RequestID 
         FROM dbo.VacationRequest 
         WHERE RequestDate = '2019-02-26' 
         AND EmployeeID = (SELECT EmployeeID FROM dbo.Employee WHERE EmployeeCode = 'PT-LIS-FI-00083')),
        '2019-04-15', '2019-04-19', 'No'
    ),
    (
        (SELECT RequestID 
         FROM dbo.VacationRequest 
         WHERE RequestDate = '2019-02-26' 
         AND EmployeeID = (SELECT EmployeeID FROM dbo.Employee WHERE EmployeeCode = 'PT-LIS-FI-00083')),
        '2019-07-29', '2019-08-21', 'Yes'
    );
GO

-- Inser��o do pedido n� 3
INSERT INTO dbo.VacationRequest (RequestDate, ApprovalDate, ManagerID, EmployeeID)
VALUES
	('2019-03-04', '2019-03-13',
	(SELECT ManagerID FROM dbo.Manager WHERE ManagerCode = 'PT-PRT-HR-000003'),
	(SELECT EmployeeID FROM dbo.Employee WHERE EmployeeCode = 'PT-BRG-AD-000100'));
GO

-- Inser��o dos per�odos de f�rias do pedido n� 3
INSERT INTO dbo.VacationPeriod (RequestID, StartDate, EndDate, Approved)
VALUES
    (
        (SELECT RequestID 
         FROM dbo.VacationRequest 
         WHERE RequestDate = '2019-03-04' 
         AND EmployeeID = (SELECT EmployeeID FROM dbo.Employee WHERE EmployeeCode = 'PT-BRG-AD-000100')),
        '2019-02-04', '2019-02-15', 'Yes'
    ),
    (
        (SELECT RequestID 
         FROM dbo.VacationRequest 
         WHERE RequestDate = '2019-03-04' 
         AND EmployeeID = (SELECT EmployeeID FROM dbo.Employee WHERE EmployeeCode = 'PT-BRG-AD-000100')),
        '2019-07-29', '2019-07-31', 'Yes'
    ),
	    (
        (SELECT RequestID 
         FROM dbo.VacationRequest 
         WHERE RequestDate = '2019-03-04' 
         AND EmployeeID = (SELECT EmployeeID FROM dbo.Employee WHERE EmployeeCode = 'PT-BRG-AD-000100')),
        '2019-12-23', '2019-12-31', 'No'
    );
GO